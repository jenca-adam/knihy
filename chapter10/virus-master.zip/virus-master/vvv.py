import os
os.system('pip install virusprank')
print('heyy, i am gonna kill u!')
from virus.functions import Virus

starter = Virus()
starter.open_website(1) #Now random websites will be opened for the next 1 minute
